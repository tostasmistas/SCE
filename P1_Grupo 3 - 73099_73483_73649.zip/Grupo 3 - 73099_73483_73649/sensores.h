#ifndef __SENSORES_H_
#define __SENSORES_H_

unsigned char tsttc (void);
void rotina_sensores_PMON(void);

#endif
