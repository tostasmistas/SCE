#ifndef __ALARMES_H_
#define __ALARMES_H_

void change_buzzer_freq(int freq);

void rotina_verificacao_alarmes(void);

void avisa_alarmes(void);

#endif
