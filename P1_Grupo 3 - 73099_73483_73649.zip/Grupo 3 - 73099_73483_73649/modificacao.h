#ifndef __MODIFICACAO_H_
#define __MODIFICACAO_H_

void rotina_modo_modificacao(void);

void rotina_sai_modificacao(void);

#endif
