#ifndef __LOCALMEMORY_H
#define __LOCALMEMORY_H

void localMemory_init(void);

#endif
