#ifndef __THREADS_H
#define __THREADS_H

#define NTHREADS 4
#define STKSIZE 4096

void cyg_threads_init(void);

#endif
